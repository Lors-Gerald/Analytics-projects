﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;

namespace WQU_DFT_Gp3D_Sub_One
{
    class Program
    {
        static Excel.Workbook workbook;
        static Excel.Application app;

        static void Main(string[] args)
        {
            app = new Excel.Application();
            app.Visible = true;
            try
            {
                workbook = app.Workbooks.Open("property_pricing.xlsx", ReadOnly: false);
            }
            catch
            {
                SetUp();
            }
            var input = "";
            while (input != "x")
            {
                PrintMenu();
                input = Console.ReadLine();
                try
                {
                    var option = int.Parse(input);
                    switch (option)
                    {
                        case 1:
                            try
                            {
                                Console.Write("Enter the size: ");
                                var size = float.Parse(Console.ReadLine());
                                Console.Write("Enter the suburb: ");
                                var suburb = Console.ReadLine();
                                Console.Write("Enter the city: ");
                                var city = Console.ReadLine();
                                Console.Write("Enter the market value: ");
                                var value = float.Parse(Console.ReadLine());

                                AddPropertyToWorksheet(size, suburb, city, value);
                            }
                            catch
                            {
                                Console.WriteLine("Error: couldn't parse input");
                            }
                            break;
                        case 2:
                            Console.WriteLine("Mean price: " + CalculateMean());
                            break;
                        case 3:
                            Console.WriteLine("Price variance: " + CalculateVariance());
                            break;
                        case 4:
                            Console.WriteLine("Minimum price: " + CalculateMinimum());
                            break;
                        case 5:
                            Console.WriteLine("Maximum price: " + CalculateMaximum());
                            break;
                        default:
                            break;
                    }
                }
                catch { }
            }

            // save before exiting
            workbook.Save();
            workbook.Close();
            app.Quit();
        }

        static void PrintMenu()
        {
            Console.WriteLine();
            Console.WriteLine("Select an option (1, 2, 3, 4, 5) " +
                              "or enter 'x' to quit...");
            Console.WriteLine("1: Add Property");
            Console.WriteLine("2: Calculate Mean");
            Console.WriteLine("3: Calculate Variance");
            Console.WriteLine("4: Calculate Minimum");
            Console.WriteLine("5: Calculate Maximum");
            Console.WriteLine();
        }

        static void SetUp()
        {
            app.Workbooks.Add();
            workbook = app.ActiveWorkbook;
            workbook.Worksheets.Add();

            Excel.Worksheet Property_sheet = workbook.Worksheets[1];
            Property_sheet.Cells[1, "A"] = "size";
            Property_sheet.Cells[1, "B"] = "suburb";
            Property_sheet.Cells[1, "C"] = "city";
            Property_sheet.Cells[1, "D"] = "value";

            workbook.SaveAs("property_pricing.xlsx");
            

        }
        static void AddPropertyToWorksheet(float size, string suburb, string city, float value)
        {
            int row = 2;
            Excel.Worksheet Add_property = workbook.Worksheets[1];
            while (true)
            {
                if (Add_property.Cells[row, "A"].Value == null)
                {
                    Add_property.Cells[row, "A"] = size;
                    Add_property.Cells[row, "B"] = suburb;
                    Add_property.Cells[row, "C"] = city;
                    Add_property.Cells[row, "D"] = value;
                    return;
                }
                row++;

            }

        }
        static float CalculateMean()
        {
            Excel.Worksheet currentSheet = workbook.Worksheets[1];
            Excel.Range MyRange = currentSheet.UsedRange;
            int row_cnt = MyRange.Rows.Count;
            float Market_values;
            float sum = 0f;
            for (int r = 2; r <= row_cnt; r++)
            {
                Market_values = (float)(currentSheet.Cells[r, 4] as Excel.Range).Value;
                sum += Market_values;
            }
            return (float)sum / row_cnt;
        }

        static float CalculateVariance()
        {
            Excel.Worksheet currentSheet = workbook.Worksheets[1];
            Excel.Range MyRange = currentSheet.UsedRange;
            int row_cnt = MyRange.Rows.Count;
            float Market_values;
            float sum = 0f;
            float sqDiff = 0f;
            for (int r = 2; r <= row_cnt; r++)
            {
                Market_values = (float)(currentSheet.Cells[r, 4] as Excel.Range).Value;
                sum += Market_values;
                float Mean = sum / row_cnt;
                sqDiff += (Market_values - Mean) * (Market_values - Mean);
            }
            return (float)sqDiff / row_cnt;
        }
        
              
        
        static float CalculateMinimum()
        {
            Excel.Worksheet currentSheet = workbook.Worksheets[1];
            Excel.Range MyRange = currentSheet.UsedRange;
            int row_cnt = MyRange.Rows.Count;
            List<float> Market_values = new List<float>();

            for (int r = 2; r <= row_cnt; r++)
            {
                Market_values = (currentSheet.Cells[r, 4] as Excel.Range).Value;


            }
            return (float)Market_values.Min();
        }
    

        static float CalculateMaximum()
        {
            Excel.Worksheet currentSheet = workbook.Worksheets[1];
            Excel.Range MyRange = currentSheet.UsedRange;
            int row_cnt = MyRange.Rows.Count;
            List<float> Market_values = new List<float>();

            for (int r = 2; r <= row_cnt; r++)
            {
                Market_values = (currentSheet.Cells[r, 4] as Excel.Range).Value;

            }
            return (float)Market_values.Max();

        }
    }
}

